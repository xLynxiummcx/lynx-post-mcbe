This adds additional effects to vibrant visuals. 
 
### Features include 

• chromatic aberration

 • fake depth of field

• enhanced volumetric fog

• enhanced bloom

 • aces tonemaping
